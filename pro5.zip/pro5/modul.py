# 𝐀𝐧𝐭𝐚𝐫𝐞𝐬[𝐃𝐨𝐥𝐥𝐲] 𝙋.𝙆_𝘽𝙊𝙏𝙎 update 01-12-2020
# Supported By babysha,dira,onay,padel,Roy Burik,Wahyu
# THANKS FOR AKI DEVAN,Ben,IGO,Dzul DK
# ™Alip•GRIND KILLER
# BTR[BONE TO REBORN [Ibal & friend]
# And All member Famz Kebotan
# Thank for 𝐄𝐋𝐅𝐎𝐗
# 𝐌𝐨𝐫𝐩𝐡𝐢𝐧𝐞 𝐁𝐨𝐭𝐬
# All member MORPHINE BOTS

# Login via  Token  & email
# ====INSTALL MELALUI VPS===== 
# sudo apt-get update
# sudo apt-get install git
# sudo apt-get install python3-pip
# sudo pip3 install rsa
# sudo pip3 install thrift==0.11.0
# sudo pip3 install requests
# sudo pip3 install pytz
# sudo pip3 install bs4
# sudo pip3 install gtts
# sudo pip3 install googletrans
# sudo pip3 install humanfriendly
# sudo pip3 install goslate
# sudo pip3 install pafy
# sudo pip3 install wikipedia
# sudo pip3 install tweepy
# sudo pip3 install youtube_dl
# git clone https://github.com/dollypk/pro5

# ====INSTALL MELALUI TERMUX=== 
# pkg install python
# apt-get update
# pip install --upgrade pip
# pkg install git -y
# pkg install nano -y
# pip3 install rsa<br>
# pip3 install thrift==0.11.0
# pip3 install requests
# pip3 install bs4
# pip3 install gtts
# pip3 install beautifulsoup
# pip3 install googletrans
# pip3 install humanfriendly
# pip3 install goslate
# pip3 install wikipedia
# pip3 install youtube_dl
# pip3 install tweepy
# pip3 install pytz
# pip3 install html5lib
# pip3 install pafy
# pip3 install livejson
# pip3 install hyper
# pip3 install httplib2
# pip3 install kbbi
# pip3 install humanize
# git clone https://github.com/dollypk/pro5

# ================================= 
# bot error pc aja line ok
http://line.me/ti/p/~resdolly_zonk

http://line.me/ti/p/~mina59.

  Like dan subscribe chanel youtube 
 
https://www.youtube.com/channel/UCC7F1rXgM0FPJSk7hkBi69Q








